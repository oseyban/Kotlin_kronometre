package com.os.kotlinkronometre
import android.annotation.SuppressLint
import android.os.Bundle
import android.os.Handler
import android.os.SystemClock
import android.view.View
import android.widget.Button
import android.widget.Chronometer
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var chronometer: Chronometer
    private lateinit var startButton: Button
    private lateinit var stopButton: Button
    private lateinit var resetButton: Button

    private var running = false
    private var pauseOffset: Long = 0

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        chronometer = findViewById(R.id.myChronometer)
        startButton = findViewById(R.id.button1)
        stopButton = findViewById(R.id.button2)
        resetButton = findViewById(R.id.button3)
        startButton.visibility = View.VISIBLE

        startButton.setOnClickListener {
            startChronometer()
        }

        stopButton.setOnClickListener {
            stopChronometer()
        }

        resetButton.setOnClickListener {
            resetChronometer()
        }
    }

    private fun startChronometer() {
        if (!running) {
            chronometer.base = SystemClock.elapsedRealtime() - pauseOffset
            chronometer.start()
            running = true
            startButton.visibility = View.INVISIBLE
            stopButton.visibility = View.VISIBLE
        }
    }

    private fun stopChronometer() {
        if (running) {
            chronometer.stop()
            pauseOffset = SystemClock.elapsedRealtime() - chronometer.base
            running = false
            startButton.setText("Devam Et")
            startButton.visibility = View.VISIBLE
            stopButton.visibility = View.INVISIBLE
        }
    }

    private fun resetChronometer() {
        chronometer.base = SystemClock.elapsedRealtime()
        pauseOffset = 0
        startButton.setText("Başla")
        if (running) {
            chronometer.stop()
            running = false
        }
        startButton.visibility = View.VISIBLE
        stopButton.visibility = View.INVISIBLE
    }
}
